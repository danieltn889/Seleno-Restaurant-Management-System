<?php
// models/StockItemCategory.php

namespace Models;

class StockItemCategory extends BaseModel {
    protected $table = 'stock_item_category';
    protected $primaryKey = 'stock_item_cat_id';
}
