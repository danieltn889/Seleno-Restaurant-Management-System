<?php
// models/StockItemCategoryGroup.php

namespace Models;

class StockItemCategoryGroup extends BaseModel {
    protected $table = 'stock_item_category_group';
    protected $primaryKey = 'stock_item_cat_group_id';
}
