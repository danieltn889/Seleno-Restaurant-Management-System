<?php
// models/MenuItem.php

namespace Models;

class MenuItem extends BaseModel {
    protected $table = 'menu_items';
    protected $primaryKey = 'menu_item_id';
}
