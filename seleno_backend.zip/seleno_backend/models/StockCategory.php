<?php
// models/StockCategory.php

namespace Models;

class StockCategory extends BaseModel {
    protected $table = 'stock_category';
    protected $primaryKey = 'stockcat_id';
}
