<?php
// models/OrderType.php

namespace Models;

class OrderType extends BaseModel {
    protected $table = 'order_type';
    protected $primaryKey = 'order_type_id';
}
