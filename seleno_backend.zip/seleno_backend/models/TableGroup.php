<?php
// models/TableGroup.php

namespace Models;

class TableGroup extends BaseModel {
    protected $table = 'tables_group';
    protected $primaryKey = 'table_group_id';
}
