<?php
// models/MenuCategory.php

namespace Models;

class MenuCategory extends BaseModel {
    protected $table = 'menu_category';
    protected $primaryKey = 'menu_cat_id';
}
