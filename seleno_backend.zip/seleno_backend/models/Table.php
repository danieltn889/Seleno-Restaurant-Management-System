<?php
// models/Table.php

namespace Models;

class Table extends BaseModel {
    protected $table = 'tables_available';
    protected $primaryKey = 'table_id';
}
