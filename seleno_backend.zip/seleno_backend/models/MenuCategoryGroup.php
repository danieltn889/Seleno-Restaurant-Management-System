<?php
// models/MenuCategoryGroup.php

namespace Models;

class MenuCategoryGroup extends BaseModel {
    protected $table = 'menu_category_groups';
    protected $primaryKey = 'menu_cat_group_id';
}
