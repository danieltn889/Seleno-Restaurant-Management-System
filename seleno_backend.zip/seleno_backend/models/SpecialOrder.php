<?php
// models/SpecialOrder.php

namespace Models;

class SpecialOrder extends BaseModel {
    protected $table = 'special_order';
    protected $primaryKey = 'special_order_id';
}
