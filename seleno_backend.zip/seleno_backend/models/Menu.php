<?php
// models/Menu.php

namespace Models;

class Menu extends BaseModel {
    protected $table = 'menu';
    protected $primaryKey = 'menu_id';
}

